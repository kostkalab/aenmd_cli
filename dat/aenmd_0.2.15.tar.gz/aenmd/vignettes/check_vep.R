

library(aenmd)
library(BiocFileCache)
#library(VariantAnnotation)

#- CLINVAR DATA
#clinvar_url <- "https://ftp.ncbi.nlm.nih.gov/pub/clinvar/vcf_GRCh38/clinvar_20221211.vcf.gz"
#clinvar_che <- bfcadd(BiocFileCache(), "clinvar", fpath=clinvar_url)

cv_imp   <- aenmd:::parse_vcf_VariantAnnotation(bfcrpath(rname = "clinvar"))
vcf_rng  <- cv_imp$vcf_rng
vcf      <- cv_imp$vcf
alt_af   <- vcf_rng$alt |> Biostrings::alphabetFrequency()
inds_out <- ((alt_af[,-(1:4)] |> rowSums()) > 0 )  |> which()
vcf_rng  <- vcf_rng[-inds_out]
vcf      <- vcf[-inds_out]
rr       <- annotate_nmd(vcf_rng); saveRDS(rr, "~/tmp/clinvar_aenmd_foo.rds")


################
#- GNOMAD CHR 21
################

vcf_url <- 'https://storage.googleapis.com/gcp-public-data--gnomad/release/2.1.1/liftover_grch38/vcf/exomes/gnomad.exomes.r2.1.1.sites.21.liftover_grch38.vcf.bgz'

#- this takes some time
vcf_imp <- aenmd:::parse_vcf_VariantAnnotation(bfcrpath(rname = vcf_url))
saveRDS(vcf_imp, "~/tmp/gnomad-chr21.rds")

vcf_rng <- vcf_imp$vcf_rng
vcf     <- vcf_imp$vcf

IFO     <- VariantAnnotation::info(vcf_imp$vcf)
vep_out <- IFO$vep
vep_hed <- VariantAnnotation::info(VariantAnnotation::header(vcf_imp$vcf))['vep',]$Description |> strsplit(split='\\|') |> unlist()
vep_hed[1] <- strsplit(vep_hed[1], split=': ')[[1]][2]

#- accessing GRanges rows really slow. Better to pre-compute.
kys <- paste(GenomicRanges::seqnames(vcf_rng) |> as.character(),
                    ":",
                    GenomicRanges::start(vcf_rng) |> stringr::str_pad(9L, pad="0"),
                    "|",                     
                    vcf_rng$ref |> as.character(),
                    "|",
                    vcf_rng$alt |> as.character(), sep="")
names(kys) <- 1:length(kys) 
collect_vars <- function(ind, kys){
    if(ind %% 100 == 0 ) message(ind)
    tmp <- strsplit(vep_out[[ind]], split="\\|")
    tmp <- lapply(tmp, \(x) {if(length(x) == length(vep_hed) -1) return (c(x,"")) ; return(x)} ) #- the last column gets dropped if empty
    mat <- tmp |> unlist() |> matrix(byrow = TRUE, ncol = length(vep_hed))
    colnames(mat) <- vep_hed
    ky <- kys[ind]
    mat <- cbind(ky, mat)
    rownames(mat) <- apply(mat[,c('ky','Feature'), drop = FALSE],1,paste, collapse='|')
    return(mat)
}

#- super slow.
mat_lst <-  sapply(seq_len(length(vep_out)), collect_vars, kys)
vep_mat <- do.call(rbind, mat_lst)
saveRDS(vep_mat, file='~/tmp/gnomad-chr21_vep-annotation.rds')
#- check how we do on VEP's stop_gained.
#=======================================

#- get only stop_gained
vep_mat_stop_gained <- vep_mat[vep_mat[,"Consequence"] |> stringr::str_detect("stop_gained"),]

#- intersect to our transcript sdt
txs_in_set <- sapply(vep_mat_stop_gained[,"Feature"],exists, envir = future::value(._EA_cds_env))
txs_in_set |> table()
#txs_in_set
#FALSE  TRUE 
# 2563  3375 
vep_mat_stop_gained_both <- vep_mat_stop_gained[txs_in_set,]

#- get the corresponding ranges
kys_both <- vep_mat_stop_gained_both[,"ky"]
kys_both <- kys_both |> stringr::str_remove('chr')
vep_mat_stop_gained_both[,"ky"] <- kys_both

vcf_rng <- GenomeInfoDb::keepStandardChromosomes(vcf_rng)
gn <- GenomeInfoDb::genome(vcf_rng)
GenomeInfoDb::genome(vcf_rng) = NA
GenomeInfoDb::seqlevelsStyle(vcf_rng) <- 'NCBI'
GenomeInfoDb::genome(vcf_rng) <- gn
vcf_rng_proc <- process_variants(vcf_rng)
names(vcf_rng_proc) <- vcf_rng_proc$key
vcf_rng_proc <- vcf_rng_proc[vcf_rng_proc$filter == 'PASS']

kys_both <- kys_both[kys_both %in% names(vcf_rng_proc)] |> unique()
vcf_rng_res <- annotate_nmd(vcf_rng_proc[kys_both], rettype = 'gr')

akey <- function(mky){
    a <- vcf_rng_res$tx_id[(vcf_rng_res$key == mky) & (vcf_rng_res$res_aenmd$is_ptc)]
    b <- vep_mat_stop_gained_both[vep_mat_stop_gained_both[,'ky'] == mky,'Feature']
    return(list(aenmd = a,vep = b))
}

rlst <- lapply(kys_both,akey)
names(rlst) <- kys_both


cfu <- function(x){
    lv  = length(x$vep)
    la  = length(x$aenmd)
    via = sum(x$vep   %in% x$aenmd)
    aiv = sum(x$aenmd %in% x$vep)
    return(c(lv,la,via,aiv))
}

tmp <- lapply(rlst, cfu)

#- VEP tx-variant stop_gained pairs, AENMD reconstruct
nvep       <- lapply(tmp, function(x) x[1]) |> unlist() |> sum()
nvep_aenmd <- lapply(tmp, function(x) x[3]) |> unlist() |> sum()

#- 99.5% of stop-gains VEP calls we find. 
nvep_aenmd/nvep 
# [1] 0.9945672

#- which ones are we missing?
aenmd_misses <- lapply(tmp, function(x) x[1] > x[3]) |> unlist() |> which()




lapply(rlst, function(x) sum(x$vep %in% x$aenmd)/length(x$vep)) |> unlist() |> mean()
#- 0.9973378
lapply(rlst, function(x) sum(x$aenmd %in% x$vep)/length(x$aenmd)) |> unlist() |> mean()
#- 0.9833964


sapply(1:length(rlst), function(i) if(any(! (rlst[[i]]$vep %in% rlst[[i]]$aenmd))) return(i))

#- we are not missing any PTCs we should have gotten:
vcf_rng_res$res_aenmd[,1] |> table()
#TRUE 
#8993 


aa = sapply(1:length(rlst), function(i) if(any(! (rlst[[i]]$vep %in% rlst[[i]]$aenmd))) return(i))
ii = unlist(aa)



#- JON: aenmd-missed VEP stop-gains:
#
MT 6264 MT_6264_G_A G A . . . ENST00000361624.2
MT 6930 MT_6930_G_A G A . . . ENST00000361624.2
MT 7053 MT_7053_G_A G A . . . ENST00000361624.2
MT 8719 MT_8719_G_A G A . . . ENST00000361899.2
MT 8782 MT_8782_G_A G A . . . ENST00000361899.2
MT 9049 MT_9049_G_A G A . . . ENST00000361899.2
#- these were found
MT_5920_G_A ENST00000361624
MT_6145_G_A ENST00000361624
MT_7896_G_A ENST00000361739
MT_8722_C_T ENST00000361899
MT_12858_C_A ENST00000361567

kys_vep <- vep_rng










vep_mat <- do.call(rbind, sapply(seq_len(length(vep_out)), collect_vars))

vep_mat <- do.call(rbind, sapply(2395:2400, collect_vars, simplify = FALSE))




